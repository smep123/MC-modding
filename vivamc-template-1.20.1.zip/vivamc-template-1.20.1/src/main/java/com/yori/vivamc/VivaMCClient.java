package com.yori.vivamc;

import net.fabricmc.api.ClientModInitializer;

public class VivaMCClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {

    }
}
