package com.yori.vivamc.item;

import com.yori.vivamc.VivaMC;
import com.yori.vivamc.block.ModBlocks;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public class ModItemsGroup {

    public static final ItemGroup VIVABUCKS_GROUP = Registry.register(Registries.ITEM_GROUP, new Identifier(VivaMC.MOD_ID, "vivabucks"),
            FabricItemGroup.builder().displayName(Text.translatable("itemgroup.vivabucks"))
                    .icon(() -> new ItemStack(ModItems.VivaBucks)).entries((displayContext, entries) -> {
                        entries.add(ModItems.VivaBucks);
                        entries.add(ModItems.Raw_VivaBucks);

                        entries.add(ModBlocks.VIVA_BLOCK);
                    }).build());

    public static void registerItemsGroup() {
        VivaMC.LOGGER.info("Registering Item Groups for" + VivaMC.MOD_ID);
    }
}
